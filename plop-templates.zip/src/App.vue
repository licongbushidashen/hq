<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  mounted() {
    debugger
    var query = window.location.search ? window.location.search.split('=')[1] : ''
    this.$store.state.query_token = query
    if (query || localStorage.getItem('query_token')) {
      if (query) {
        localStorage.setItem('query_token', query)
      }
      console.log(localStorage.getItem('query_token'))
      // var params = {
      //   grant_type: 'onekey',
      //   access_token: query.accessToken,
      //   client_id: 'Feedbacks_App',
      //   client_secret: '1q2w3e*'
      // }
      var params = {
        grant_type: 'onekey',
        access_token: query || localStorage.getItem('query_token'),
        client_id: 'Logistics_App',
        client_secret: '1q2w3e*'
      }
      this.$api.post(this.rzss, params, { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' }).then(res => {
        if (!res.error) {
          this.$store.state.vuex_token = res.data.access_token
          this.$api.get(`${this.https}/api/abp/application-configuration`).then(info => {
            if (!res.error) {
              this.$store.state.vuex_user = info.data

              // this.$u.api.getAbpConfiguration().then(cfg => {
              //   this.$u.vuex('vuex_config', cfg)
              //   if (cfg.auth.grantedPolicies['Feedbacks.Audit']) {
              //     this.$u.vuex('vuex_auditPolices', true)
              //   }
              //   this.$u.route('/pages/feedbacks/index')
              // })
            } else {
              this.title = '对不起'
              this.info = '进入系统失败，错误码:10022'
            }
          })
        } else {
          this.title = '对不起'
          this.info = '进入系统失败，错误码:10021'
        }
      })
    } else {
      if (this.vuex_config.currentUser === undefined || !this.vuex_config.currentUser.isAuthenticated) {
        this.title = '非法访问'
        this.info = '请从正规途径进入系统'
      } else {
        this.$u.route('/pages/feedbacks/index')
      }
    }
  }
}
</script>
