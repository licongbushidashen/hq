<template>
  <div class="app-container">
    <div style="margin-bottom:20px">
      <el-button type="primary" size="small" icon="el-icon-edit" style="margin-left:20px" @click="add">
        新增
      </el-button>
      <el-select v-model="value" placeholder="请选择" style="margin-left:20px" clearable @change="ops">
        <el-option v-for="item in options" :key="item.id" :label="item.name" :value="item.id">
        </el-option>
      </el-select>
    </div>
    <el-table v-loading="listLoading" :data="list" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" label="ID" width="80">
        <template slot-scope="scope">
          <span>{{ scope.row.id }}</span>
        </template>
      </el-table-column>

      <el-table-column width="180px" align="center" label="创建时间">
        <template slot-scope="scope">
          <span>{{ scope.row.creationTime | parseTime('{y}-{m}-{d} {h}:{i}') }}</span>
        </template>
      </el-table-column>

      <!-- <el-table-column width="120px" align="center" label="作者">
        <template slot-scope="scope">
          <span>{{ scope.row.author }}</span>
        </template>
      </el-table-column> -->

      <!-- <el-table-column class-name="status-col" label="Status" width="110">
        <template slot-scope="{row}">
          <el-tag :type="row.status | statusFilter">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column> -->

      <el-table-column min-width="300px" label="Title">
        <template slot-scope="{row}">
          <router-link :to="'/example/edit/'+row.id" class="link-type">
            <span>{{ row.title }}</span>
          </router-link>
        </template>
      </el-table-column>

      <el-table-column align="center" label="Actions" width="240">
        <template slot-scope="scope">
          <router-link :to="'/example/edit/'+scope.row.id">
            <el-button type="primary" size="small" icon="el-icon-edit">
              修改
            </el-button>
          </router-link>
          <el-button type="primary" size="small" icon="el-icon-edit" style="margin-left:20px" @click="del(scope.row)">
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="listQuery.SkipCount" :limit.sync="listQuery.MaxResultCount" @pagination="getList" />
  </div>
</template>

<script>
import Pagination from '@/components/Pagination' // Secondary package based on el-pagination

export default {
  name: 'ArticleList',
  components: { Pagination },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'info',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      options: [],
      value: '',
      list: null,
      total: 0,
      listLoading: true,
      listQuery: {
        SkipCount: 0,
        MaxResultCount: 20
      }
    }
  },
  created() {
    this.getList()
    this.op()
  },
  methods: {
    ops() {
      debugger
      this.getList()
    },
    op() {
      this.$api.get(`${this.https}/api/logistics/articleCategory`, {}).then(res => {
        this.options = res.items
      })
    },
    add() {
      this.$router.push('/example/create')
    },
    getList() {
      this.listLoading = true
      var x = {
        SkipCount: this.listQuery.SkipCount > 0 ? (this.listQuery.SkipCount - 1) * this.listQuery.MaxResultCount : this.listQuery.SkipCount,
        MaxResultCount: this.listQuery.MaxResultCount
      }
      if (this.value) {
        x.Category = this.value
      }
      this.$api.get(`http://zjlab-logistics.demo.wy5u.com/api/logistics/article`, x).then(res => {
        this.list = res.items
        this.total = res.totalCount
        this.listLoading = false
      })
    },
    del(row) {
      let data = {
        id: row.id
      }
      this.$api.delete('http://zjlab-logistics.demo.wy5u.com/api/logistics/article', data).then(res => {
        this.getList()
      })
    }
  }
}
</script>

<style scoped>
.edit-input {
  padding-right: 100px;
}
.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}
</style>
