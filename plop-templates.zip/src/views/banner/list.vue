<template>
    <div class="app-container">
        <div style="margin-bottom:20px">
            <el-button type="primary" size="small" icon="el-icon-edit" style="margin-left:20px" @click="add">
                新增
            </el-button>
            <el-select v-model="value" placeholder="请选择" style="margin-left:20px" clearable @change="ops">
                <el-option v-for="item in options" :key="item.id" :label="item.name" :value="item.id">
                </el-option>
            </el-select>
        </div>
        <el-table v-loading="listLoading" :data="list" border fit highlight-current-row style="width: 100%">
            <el-table-column align="center" label="ID" width="80">
                <template slot-scope="scope">
                    <span>{{ scope.row.id }}</span>
                </template>
            </el-table-column>

            <el-table-column width="180px" align="center" label="创建时间">
                <template slot-scope="scope">
                    <span>{{ scope.row.creationTime | parseTime('{y}-{m}-{d} {h}:{i}') }}</span>
                </template>
            </el-table-column>

            <!-- <el-table-column width="120px" align="center" label="作者">
        <template slot-scope="scope">
          <span>{{ scope.row.author }}</span>
        </template>
      </el-table-column> -->

            <!-- <el-table-column class-name="status-col" label="Status" width="110">
        <template slot-scope="{row}">
          <el-tag :type="row.status | statusFilter">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column> -->

            <el-table-column min-width="300px" label="Title">
                <template slot-scope="{row}">
                    <router-link :to="'/example/edit/'+row.id" class="link-type">
                        <span>{{ row.title }}</span>
                    </router-link>
                </template>
            </el-table-column>

            <el-table-column align="center" label="Actions" width="240">
                <template slot-scope="scope">
                    <el-button type="primary" size="small" icon="el-icon-edit" @click="edit(scope.row)">
                        修改
                    </el-button>
                    <el-button type="primary" size="small" icon="el-icon-edit" style="margin-left:20px" @click="del(scope.row)">
                        删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-dialog title="新增分类" :visible.sync="dialogTableVisible" width="30%">
            <!-- <div style="margin-bottom:20px">
                <label style="margin-right:5px">{{from.flag?'创建子节点':' 创建根节点'}}:</label>
                <el-switch v-model="from.flag" active-color="#13ce66" inactive-color="#13ce66">
                </el-switch>
            </div> -->
            <div>
                <div class="jdcx">
                    <label>类型选择:</label>
                    <el-select v-model="value1" placeholder="请选择">
                        <el-option v-for="item in options1" :key="item.id" :label="item.name" :value="item.id">
                        </el-option>
                    </el-select>
                </div>
                <!-- <div class="jdcx" v-if="!from.flag">
                    <label>根节点:</label>
                    <el-input class="el_input_g" v-model="from.sname" />
                </div> -->
                <div class="jdcx">
                    <label>名称:</label>
                    <el-input class="el_input_g" v-model="from.name" />
                </div>
            </div>
            <div>
                <div class="jdcx">
                    <label>地址链接:</label>
                    <el-input class="el_input_g" v-model="from.url" />
                </div>

                <div class="jdcx">
                    <label>图片上传:</label>
                    <el-upload class="avatar-uploader" :action="https+'/api/logistics/files/images/upload'" :show-file-list="false" :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload">
                        <img v-if="from.coverImage" :src="from.coverImage" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </div>
            </div>
            <div>
                <div class="jdcx">
                    <label>背景颜色:</label>
                    <div @click="colorInputClick">
                        <el-input disabled :value="from.bgColor" @click="colorInputClick"></el-input>
                    </div>
                    <div v-show="isShowColors" class="color-select-layer">
                        <sketch v-model="from.bgColor" @input="colorValueChange"></sketch>
                    </div>
                </div>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogTableVisible = false">取 消</el-button>
                <el-button type="primary" @click="addtype">确 定</el-button>
            </span>
        </el-dialog>
        <pagination v-show="total>0" :total="total" :page.sync="listQuery.SkipCount" :limit.sync="listQuery.MaxResultCount" @pagination="getList" />
    </div>
</template>

<script>
import { Sketch } from 'vue-color'
import Pagination from '@/components/Pagination' // Secondary package based on el-pagination

export default {
  name: 'ArticleList',
  components: { Pagination, Sketch },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'info',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      editing: false,
      isShowColors: true,
      color: '#3f3f3f',
      dialogTableVisible: false,
      id: '',
      options: [
        {
          name: 'banner',
          id: 0
        },
        {
          name: '之江生活',
          id: 1
        },
        {
          name: '全部',
          id: 2
        }
      ],
      value: 2,
      options1: [
        {
          name: 'banner',
          id: 0
        },
        {
          name: '之江生活',
          id: 1
        }
      ],
      value1: 0,
      list: null,
      total: 0,
      from: {
        title: '',
        bgColor: '',
        url: '',
        fill: '',
        coverImage: ''
      },
      listLoading: true,
      listQuery: {
        SkipCount: 0,
        MaxResultCount: 20
      }
    }
  },
  created() {
    this.getList()
    // this.op()
  },
  methods: {
    edit(val) {
      this.editing = true
      this.from = {
        title: val.title,
        bgColor: val.bgColor,
        url: val.url,
        fill: val.fill,
        coverImage: val.coverImage
      }
      this.dialogTableVisible = true
      this.id = val.id
    },
    addtype() {
      var data = {
        name: this.from.sname
      }
      let types = this.editing ? 'put' : 'post'
      if (this.editing) {
        data.id = this.id
      }
      this.$api[types](`${this.https}/api/logistics/banner`, data).then(res => {
        ;(this.from = {
          title: '',
          bgColor: '',
          url: '',
          fill: '',
          coverImage: ''
        }),
          (this.editing = false)
        this.dialogTableVisible = false
        this.getList()
      })
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg'
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!')
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!')
      }
      return isJPG && isLt2M
    },
    handleAvatarSuccess(res, file) {
      this.from.url = URL.createObjectURL(file.raw)
    },
    // 颜色输入框点击事件处理
    colorInputClick() {
      this.isShowColors = !this.isShowColors
    },
    // 颜色值改变事件处理
    colorValueChange(val) {
      console.log(val)

      // 取颜色对象的十六进制值
      this.from.bgColor = val.hex
    },
    ops() {
      this.getList()
    },
    // op() {
    //   this.$api.get(`${this.https}/api/logistics/banner`, {}).then(res => {
    //     this.options = res.items
    //   })
    // },
    add() {
      this.dialogTableVisible = true
    },
    getList() {
      debugger
      this.listLoading = true
      var x = {
        SkipCount: this.listQuery.SkipCount > 0 ? (this.listQuery.SkipCount - 1) * this.listQuery.MaxResultCount : this.listQuery.SkipCount,
        MaxResultCount: this.listQuery.MaxResultCount
      }
      if (this.value != 2) {
        x.Category = this.value
      }
      this.$api.get(`${this.https}/api/logistics/banner`, x).then(res => {
        this.list = res.items
        this.total = res.totalCount
        this.listLoading = false
      })
    },
    del(row) {
      let data = {
        id: row.id
      }
      this.$api.delete(`${this.https}/api/logistics/banner`, data).then(res => {
        this.getList()
      })
    }
  }
}
</script>

<style scoped>
.edit-input {
  padding-right: 100px;
}
.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}
</style>
