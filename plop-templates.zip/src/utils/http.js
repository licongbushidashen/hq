import axios from 'axios'

function apiAxios(method, url, params, header = {
  'content-Type': 'application/json; charset=utf-8'
}) {
  //   if (params) {
  //     params = filterNull(params);
  //   }
  //   header.Authorization = 'Bearer ' + store.state.vuex_token
  return new Promise((resolve, reject) => {
    var data;
    if (method == 'PUT') {
      var id = params.id
      delete params.id
      data = params
      params = {
        id: id
      }
    } else {
      var data = method === 'POST' || method === 'PUT' ? params : null;
      params = method === 'GET' || method === 'DELETE' ? params : null;
    }
    axios({
      method: method,
      headers: header,
      url: url,
      data: data,
      params: params,
      withCredentials: false,
      timeout: 60000
    }).then(function (res) {
      if (res.status == 200 || res.status == 204) {
        resolve(res.data);
      } else {
        console.log(res);
      }
    }).catch(function (err) {
      reject(err);
    });
  });
}
export default {
  get: function (url, params, headers) {
    return apiAxios('GET', url, params, headers);
  },
  post: function (url, params, headers) {
    return apiAxios('POST', url, params, headers);
  },
  put: function (url, params, headers) {
    return apiAxios('PUT', url, params, headers);
  },
  delete: function (url, params, headers) {
    return apiAxios('DELETE', url, params, headers);
  },
}
